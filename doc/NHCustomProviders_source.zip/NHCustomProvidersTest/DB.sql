﻿-- database script for the tests

CREATE DATABASE NHCustomProvidersTest
GO

USE NHCustomProvidersTest

CREATE TABLE Users (
	userId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_User PRIMARY KEY,
	username nvarchar(50) NOT NULL,
	email nvarchar(100) NOT NULL,
	password nvarchar(256) NOT NULL,
	passwordSalt nvarchar(64) NULL,
	passwordFormat int NOT NULL,
	passwordQuestion nvarchar(512) NOT NULL,
	passwordAnswer nvarchar(512) NOT NULL,
	failedPasswordAttemptCount int NOT NULL,
	failedPasswordAttemptWindowStart smalldatetime NULL,
	failedPasswordAnswerAttemptCount int NOT NULL,
	failedPasswordAnswerAttemptWindowStart smalldatetime NULL,
	lastPasswordChangedDate smalldatetime NULL,
	creationDate smalldatetime NOT NULL,
	lastActivityDate smalldatetime NOT NULL,
	isApproved bit NOT NULL,
	isLockedOut bit NOT NULL,
	lastLockOutDate smalldatetime NULL,
	lastLoginDate smalldatetime NULL,
	comments nvarchar(max) NULL,
	
	name nvarchar(256) NOT NULL,
	surname nvarchar(256) NOT NULL,
	company nvarchar(256) NOT NULL,
	phone nvarchar(16) NULL,
	postalCode nvarchar(50) NULL
)

CREATE TABLE Roles (
    roleId int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Role PRIMARY KEY,
    name nvarchar(50) NOT NULL,
)

INSERT INTO Roles(name) VALUES('Developer')
INSERT INTO Roles(name) VALUES('Tester')
INSERT INTO Roles(name) VALUES('Project Manager')

CREATE TABLE UsersInRoles (
    userId int NOT NULL CONSTRAINT FK_UserRole FOREIGN KEY REFERENCES Users(userId),
    roleId int NOT NULL CONSTRAINT FK_RoleUser FOREIGN KEY REFERENCES Roles(roleId),
    CONSTRAINT PK_UsersInRoles PRIMARY KEY (userId, roleId)
)
