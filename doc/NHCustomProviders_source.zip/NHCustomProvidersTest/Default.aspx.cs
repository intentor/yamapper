﻿using System;

namespace NHCustomProvidersTest
{
	public partial class Default : System.Web.UI.Page
	{
		#region Methods

		protected void Page_Load(object sender, EventArgs e)
		{
		}

		#endregion
	}
}