﻿using System;
using System.Reflection;
using System.Text;
using System.Web.Security;
using NHCustomProviders;

namespace NHCustomProvidersTest.Members
{
	public partial class Default : System.Web.UI.Page
	{
		#region Methods

		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack) {
				NHCustomMembershipProvider membershipProvider = (NHCustomMembershipProvider)Membership.Providers["NHCustomProviderFull"];

				if (membershipProvider == null) {
					throw new Exception("NHCustomProviderFull has not been configured in the web.config file");
				}

				MembershipUser user = membershipProvider.GetUser(User.Identity.Name, false);
				PropertyInfo[] props = user.GetType().GetProperties();

				StringBuilder sb = new StringBuilder();
				sb.Append("<h1>MembershipUser data:</h1>");

				foreach (PropertyInfo prop in props) {
					sb.AppendFormat("{0} = {1}", prop.Name, prop.GetValue(user, null));
					sb.Append("<br />");
				}
				lMembershipUser.Text = sb.ToString();

				NHCustomRoleProvider roleProvider = (NHCustomRoleProvider)Roles.Providers["NHCustomProviderFull"];

				if (roleProvider == null) {
					throw new Exception("NHCustomProviderFull has not been configured in the web.config file");
				}

				string[] allRoles = roleProvider.GetAllRoles();
				string[] roles = roleProvider.GetRolesForUser(User.Identity.Name);

				lRoles.Text = String.Join(" - ", allRoles);
				lAsignedRoles.Text = String.Join(" - ", roles);

				lbRoles.DataSource = allRoles;
				lbRoles.DataBind();
			}
		}

		protected void bAddRole_Click(object sender, EventArgs e)
		{
			NHCustomRoleProvider roleProvider = (NHCustomRoleProvider)Roles.Providers["NHCustomProviderFull"];

			if (roleProvider == null) {
				throw new Exception("NHCustomProviderFull has not been configured in the web.config file");
			}

			if (lbRoles.SelectedIndex != -1) {
				roleProvider.AddUsersToRoles(new string[] { User.Identity.Name }, new string[] { lbRoles.SelectedValue });

				string[] roles = roleProvider.GetRolesForUser(User.Identity.Name);
				lAsignedRoles.Text = String.Join(" - ", roles);
			}
		}

		#endregion
	}
}