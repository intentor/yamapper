﻿using System;
using System.Web.Security;
using System.Web.UI.WebControls;
using NHCustomProviders;
using NHCustomProvidersTest.Model;
using NHibernate;

namespace NHCustomProvidersTest
{
	public partial class Register : System.Web.UI.Page
	{
		#region Methods

		protected void Page_Load(object sender, EventArgs e)
		{
		}

		protected void CreateUserExWizard1_CreateUserEx(object sender, CreateUserExEventArgs e)
		{
			if (Page.IsValid) {
				TextBox UserName = (TextBox)CreateUserExWizard1.CreateUserStep.ContentTemplateContainer.FindControl("UserName");
				TextBox Email = (TextBox)CreateUserExWizard1.CreateUserStep.ContentTemplateContainer.FindControl("Email");
				TextBox Question = (TextBox)CreateUserExWizard1.CreateUserStep.ContentTemplateContainer.FindControl("Question");

				TextBox Name = (TextBox)CreateUserExWizard1.CreateUserStep.ContentTemplateContainer.FindControl("Name");
				TextBox Surname = (TextBox)CreateUserExWizard1.CreateUserStep.ContentTemplateContainer.FindControl("Surname");
				TextBox Company = (TextBox)CreateUserExWizard1.CreateUserStep.ContentTemplateContainer.FindControl("Company");
				TextBox Phone = (TextBox)CreateUserExWizard1.CreateUserStep.ContentTemplateContainer.FindControl("Phone");
				TextBox PostalCode = (TextBox)CreateUserExWizard1.CreateUserStep.ContentTemplateContainer.FindControl("PostalCode");

				// now, we're ready to create the user
				User user = new User();

				// get the membership provider
				NHCustomMembershipProvider membershipProvider = (NHCustomMembershipProvider)Membership.Providers["NHCustomProviderFull"];

				if (membershipProvider == null) {
					throw new Exception("NHCustomProviderFull has not been configured in the web.config file");
				}

				// set the user data that can be accessed by the membership provider
				user.Username = UserName.Text;
				user.Password = e.EncodedPassword;
				user.PasswordSalt = e.EncodedPasswordSalt;
				user.PasswordFormat = membershipProvider.PasswordFormat;
				user.PasswordQuestion = Question.Text;
				user.PasswordAnswer = e.EncodedAnswer;
				user.Email = Email.Text;
				user.CreationDate = user.LastActivityDate = DateTime.Now;
				user.IsApproved = !CreateUserExWizard1.DisableCreatedUser;

				// set the other data
				user.Name = Name.Text;
				user.Surname = Surname.Text;
				user.Company = Company.Text;
				user.Phone = Phone.Text;
				user.PostalCode = PostalCode.Text;

				ISessionFactory sessionFactory = (ISessionFactory)Application["SessionFactory"];
				ISession session = sessionFactory.OpenSession();
				ITransaction trans = null;

				try {
					trans = session.BeginTransaction();
					session.Save(user);
					session.Flush();
					trans.Commit();
				} catch (Exception exc) {
					if (trans != null) {
						trans.Rollback();
					}

					throw exc;
				} finally {
					session.Close();
				}
			}
		}

		#endregion
	}
}