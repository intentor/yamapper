﻿using System;
using System.Reflection;
using NHCustomProvidersTest.Model;
using NHibernate;
using NHibernate.Cfg;

namespace NHCustomProvidersTest
{
	public class Global : System.Web.HttpApplication
	{
		#region Methods

		protected void Application_Start(object sender, EventArgs e)
		{
			// creates the session factory and saves it for latter
			// do this in a HttpModule for serious applications
			Configuration cfg = new Configuration();
			cfg.Configure();
			cfg.AddAssembly(Assembly.GetAssembly(typeof(User)));
			ISessionFactory sessionFactory = cfg.BuildSessionFactory();
			Application["SessionFactory"] = sessionFactory;
		}

		protected void Session_Start(object sender, EventArgs e)
		{
		}

		protected void Application_BeginRequest(object sender, EventArgs e)
		{
		}

		protected void Application_AuthenticateRequest(object sender, EventArgs e)
		{
		}

		protected void Application_Error(object sender, EventArgs e)
		{
		}

		protected void Session_End(object sender, EventArgs e)
		{
		}

		protected void Application_End(object sender, EventArgs e)
		{
		}

		#endregion
	}
}