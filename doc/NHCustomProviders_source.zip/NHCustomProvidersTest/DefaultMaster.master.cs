using System;

public partial class DefaultMaster_Default : System.Web.UI.MasterPage
{
	#region Methods

	protected void Page_Load(object sender, EventArgs e)
	{
	}

	protected void LoginStatus1_LoggedOut(object sender, EventArgs e)
	{
		Response.Redirect("~/Default.aspx");
	}

	#endregion
}